#ifndef WW_H
#define WW_H

#include <QDialog>
#include <QMediaPlayer>
#include <QMediaPlaylist>

namespace Ui {
class ww;
}

class ww : public QDialog
{
    Q_OBJECT

public:
    explicit ww(QWidget *parent = nullptr);
    ~ww();

private slots:
    void on_Play_button_clicked();

private:
    Ui::ww *ui;
    QMediaPlayer* player;
};

#endif // WW_H
