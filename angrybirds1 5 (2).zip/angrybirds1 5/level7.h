#ifndef LEVEL7_H
#define LEVEL7_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level7: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level7();
    void loadLevel7();
};

#endif // LEVEL7_H
