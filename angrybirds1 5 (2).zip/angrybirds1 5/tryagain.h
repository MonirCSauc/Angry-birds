#ifndef TRYAGAIN_H
#define TRYAGAIN_H


#include <QDialog>

namespace Ui {
class tryagain;
}

class tryagain : public QDialog
{
    Q_OBJECT

public:
    explicit tryagain(QWidget *parent = nullptr);
    ~tryagain();

private slots:
    //void on_Exit_clicked();

    void on_tryagain_2_clicked();

    void on_Exit_2_clicked();

private:
    Ui::tryagain *ui;
};

#endif // TRYAGAIN_H
