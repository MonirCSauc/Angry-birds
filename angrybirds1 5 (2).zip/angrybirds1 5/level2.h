#ifndef LEVEL2_H
#define LEVEL2_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level2: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level2();
    void loadLevel2();
};

#endif // LEVEL2_H
