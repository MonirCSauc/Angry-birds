#ifndef BARRIER_H
#define BARRIER_H
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>


class barrier:public QGraphicsPixmapItem, public QObject
{
public:
    barrier();
    QPointF getPos();
private:
    QPointF position;
};

#endif // BARRIER_H
