#include "level8.h"

Level8::Level8()
{
    QGraphicsTextItem* newLevel= new QGraphicsTextItem("Level 8");
    newLevel->setFont(QFont("times", 40));
    newLevel->setDefaultTextColor(Qt::green);
    newLevel->setPos(300, 250);
    QTimer::singleShot(1000, [=](){
        PhysicsEngine::scene->addItem(newLevel);
    });
    QTimer::singleShot(7000, [=](){PhysicsEngine::scene->removeItem(newLevel);});
}

void Level8::loadLevel8()
{

    Gen_barrier(600,500);
    Gen_barrier(600, 400);
    Gen_barrier(600, 300);
    Gen_target(990, 235);
    Gen_box(970, 490);
    Gen_box(970, 390);
    Gen_box(970, 290);
    Gen_target(1090, 135);
    Gen_box(1070, 490);
    Gen_box(1070, 390);
    Gen_box(1070, 290);
    Gen_box(1070, 190);
    PhysicsEngine::scene->update();

}
