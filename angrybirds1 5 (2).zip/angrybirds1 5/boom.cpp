#include "boom.h"

boom::boom()
{
    QPixmap boomItem (":/Images/explode.png");
    boomItem = boomItem.scaledToWidth(50);
    boomItem = boomItem.scaledToHeight(50);
    setPixmap(boomItem);
}
