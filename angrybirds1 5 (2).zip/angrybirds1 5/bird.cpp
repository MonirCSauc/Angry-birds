#include "bird.h"
#include <ctime>


bird::bird(PhysicsEngine* p):flyingSound(new QMediaPlayer(this))
{
    if(level==10){
        QPixmap birdpixmap(":/Images/green bird.png");
        birdpixmap = birdpixmap.scaledToWidth(50);
        birdpixmap = birdpixmap.scaledToHeight(50);
        setPixmap(birdpixmap);
    }
    else{
    int i = 0;
    i = rand()%5; //random function that decides the character (bird) image that will be displayed
    if(i==0){
        QPixmap birdpixmap(":/Images/green bird.png");
        birdpixmap = birdpixmap.scaledToWidth(50);
        birdpixmap = birdpixmap.scaledToHeight(50);
        setPixmap(birdpixmap);
    }
    if (i == 1){

        QPixmap birdpixmap(":/Images/black bird.png");
        birdpixmap = birdpixmap.scaledToWidth(50);
        birdpixmap = birdpixmap.scaledToHeight(50);
        setPixmap(birdpixmap);

    }
    if ( i ==3 ){
    QPixmap birdpixmap(":/Images/pngegg (" + QString::number(i) + ").png");
    birdpixmap = birdpixmap.scaledToWidth(50);
    birdpixmap = birdpixmap.scaledToHeight(50);
    setPixmap(birdpixmap);

    }

    if ( i ==2 ){


    QPixmap birdpixmap(":/Images/yellowbird.png");
    birdpixmap = birdpixmap.scaledToWidth(60);
    birdpixmap = birdpixmap.scaledToHeight(60);
    setPixmap(birdpixmap);


    }

    if(i==4)
    {
    QPixmap birdpixmap(":/Images/blue.png");
    birdpixmap = birdpixmap.scaledToWidth(60);
    birdpixmap = birdpixmap.scaledToHeight(60);
    setPixmap(birdpixmap);

    }}
    currentengine = p;
    flyingSound->setMedia(QUrl("qrc:/Sounds/81. Sfx - Bird 05 Flying.mp3"));


}

void bird::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
    Offset = event->scenePos();

}

void bird::mouseMoveEvent(QGraphicsSceneMouseEvent* event)
{
    // Get the new position of the bird based on the mouse event
    newPos = event->scenePos();
    // Define the allowed boundaries for the bird's movement
    qreal minX = 130 - 125;
    qreal maxX = 130 + 100;
    qreal minY = 425 - 150;
    qreal maxY = 425 + 175;
    // Ensure the new position stays within the defined boundaries
    newPos.setX(qBound(minX, newPos.x(), maxX - boundingRect().width()));
    newPos.setY(qBound(minY, newPos.y(), maxY - boundingRect().height()));
    //call the recoil function in slingshot class which sets the current bird position and moved the string accordingly
    recoil(newPos);
    // Set the new position for the bird
    setPos(newPos);


}

void bird::launch(double speed, double angle)
{
    // Convert angle from degrees to radians
    double angleRad = angle * M_PI / 180.0;
    // Calculate horizontal and vertical components of velocity
    vx = speed * cos(angleRad);
    vy = speed * sin(angleRad);

    // Start a timer to update the position by calling the motion function every 10 milliseconds
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &bird::motion);
    timer->start(10);

}

void bird::motion()
{
    qreal maxY = scene()->height();
    qreal maxX = scene()->width();

    double newX = x() + vx;
    double newY = y() - vy;
    setPos(newX, newY);


    vy -= 0.07;
    collideWithTarget();
    //the if statement checks if the bird moved out of bounds or if collided with a barrier or a box
    //if it did, it decrements trials and puts the bird in its initial position again
    if ((newY >= maxY - boundingRect().height()&&!targetcollide) || (newX >= maxX - boundingRect().height()&&!targetcollide)
        ||(barriercolllide&&!targetcollide) || (boxcollide && !targetcollide)) {
        disconnect(timer, &QTimer::timeout, this, &bird::motion);
        timer->stop();
        trialcount--;
        //scene()->removeItem(this); //removed the bird before putting it in its initial position again
        //delete this;
        //setPos(175, 410);
        barriercolllide = false;
        boxcollide=false;
        currentengine->spawn();
        vx = 0;
        vy = 0;

        setFlag(QGraphicsItem::ItemIsFocusable);
        setFocus();


        }

}

void bird::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
    // Calculate the angle of launch based on mouse release position and offset
    double angle = atan2(newPos.y() - Offset.y(), Offset.x() - newPos.x())*(180 / M_PI);
    // Calculate the horizontal distance (difference in x) between release position and offset
    double diff_inx =  Offset.x() - newPos.x();
    //calling the reverse function in slingshot class to return the string to its unstretched position
    reverse();

    this->launch(diff_inx*0.12, angle);
    flyingSound->setVolume(50);
    flyingSound->play();

}

void bird:: delay(int milliseconds)
{
    QEventLoop loop;
    QTimer::singleShot(milliseconds, &loop, &QEventLoop::quit);
    loop.exec();
}

bool bird::collideWithTarget()
{
    //get a list of all the items that are colliding with the bird
    QList<QGraphicsItem*> colliding_items= collidingItems();
    for(QGraphicsItem *item : colliding_items)
    {
        Target * target = dynamic_cast<Target*>(item);
        barrier* Barrier = dynamic_cast<barrier*>(item);
        Box* boxx = dynamic_cast<Box*>(item);
        if(target) //if bird has collided with target
        {

            QPixmap boom (":/Images/explode.png"); //display an explosion image
            boom = boom.scaledToHeight(70);
            boom = boom.scaledToWidth(70);
            QGraphicsPixmapItem* explosion = new QGraphicsPixmapItem;
            explosion->setPixmap(boom);
            explosion->setPos(target->getPos());

            scene()->removeItem(item); //removes target
            delete item;
            targetCount--; //decrements target count
            trialcount++;
            scene()->addItem(explosion);
            delay(50); //delays the explosion so it is visible
            scene()->removeItem(explosion);

            if (targetCount==0){ //if no more targets are in the scene
                QGraphicsTextItem* levelDone= new QGraphicsTextItem("Level Passsed Successfully!"); //display message
                levelDone->setFont(QFont("times", 40));
                levelDone->setDefaultTextColor(QColor(4,175,112));
                levelDone->setPos(300, 250);
                scene()->addItem(levelDone);

                delay(1000);
                level++;
                currentengine->loadLevel(); //increase the level count and call the function to go to new level
                targetcollide = true;
                return targetcollide;
                QTimer::singleShot(1000, [=](){
                    scene()->removeItem(levelDone);
                }); //removes the level passed successfully message after 1 second
            }
        }
        if(Barrier) //check if it collided with a barrier
        {
            timer->stop();
            barriercolllide = true;
            return barriercolllide ;
        }
        if(boxx) //check if it collided with a box
        {
            timer->stop();
            boxcollide = true;
            return boxcollide ;

        }

    }

    return false;
}

