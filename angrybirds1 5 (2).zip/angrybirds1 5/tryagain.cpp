#include "tryagain.h"
#include "physicsengine.h"
#include "ui_tryagain.h"

#include <QApplication>

tryagain::tryagain(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::tryagain)
{
    ui->setupUi(this);
}

tryagain::~tryagain()
{
    delete ui;
}


/*void tryagain::on_tryagain_2_clicked()
{
    // Assuming that 'parent' is a valid pointer to the parent widget or nullptr if there's no parent
    PhysicsEngine* p = new PhysicsEngine;

    if (p) {
        p->loadLevel();
        this->close();
    } else {
        qDebug() << "Failed to cast parent to PhysicsEngine";
    }
}



void tryagain::on_Exit_2_clicked()
{
    exit(1);
}
*/
