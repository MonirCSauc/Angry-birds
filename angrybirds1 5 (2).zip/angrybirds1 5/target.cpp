#include "target.h"
//#include "cat.h"

Target::Target()
{
    QPixmap targetpixmap (":/Images/newpig.png");
    targetpixmap = targetpixmap.scaledToWidth(60);
    targetpixmap = targetpixmap.scaledToHeight(60);
    setPixmap(targetpixmap);

}

QPointF Target::getPos()
{
    return this->pos();
}


QRectF Target:: boundingRect() {
    return QRectF(-20, -20, 40, 40);
}
