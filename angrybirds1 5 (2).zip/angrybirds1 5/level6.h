#ifndef LEVEL6_H
#define LEVEL6_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>


class Level6: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level6();
    void loadLevel6();
    void Gen_barrier(double X , double Y);
};

#endif // LEVEL6_H
