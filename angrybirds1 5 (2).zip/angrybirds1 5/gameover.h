#ifndef GAMEOVER_H
#define GAMEOVER_H


class GameOver
{
public:
    GameOver();
};

#endif // GAMEOVER_H
