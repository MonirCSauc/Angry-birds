#ifndef BOX_H
#define BOX_H
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>

class Box: public QGraphicsPixmapItem, public QObject
{
public:
    Box();
};

#endif // BOX_H
