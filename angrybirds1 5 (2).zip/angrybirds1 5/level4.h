#ifndef LEVEL4_H
#define LEVEL4_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level4: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level4();
    void loadLevel4();
};

#endif // LEVEL4_H
