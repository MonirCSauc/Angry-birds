#ifndef LEVEL10_H
#define LEVEL10_H
#define LEVEL2_H
#include "physicsengine.h"
#include "barrier.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level10: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level10();
    void loadLevel10();
    void Gen_barrier( double X , double Y);
};

#endif // LEVEL10_H
