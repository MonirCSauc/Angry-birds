#ifndef BIRD_H
#define BIRD_H
#include "physicsengine.h"
#include <QApplication>
#include "target.h"
#include "box.h"
#include "barrier.h"
#include <QGraphicsScene>
#include <cmath>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include <QGraphicsTextItem>
#include <QGraphicsSceneMouseEvent>
#include <QMouseEvent>
#include <QTimer>
#include <QTimerEvent>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QUrl>
#include "slingshot.h"

extern int level;
extern int targetCount;
class bird:public Slingshot
{


private:
    PhysicsEngine* currentengine;
    QPointF Offset;
    QPointF newPos;
    double vx , vy;
    QTimer* timer;
    bool targetcollide=false;
    bool barriercolllide = false ;
    bool boxcollide = false;
    QMediaPlayer* flyingSound;



public:
    bird(PhysicsEngine *p);
    void launch(double speed, double angle);
    void motion ();
    void delay(int milliseconds);
    bool collideWithTarget();



public slots:

    void mouseReleaseEvent(QGraphicsSceneMouseEvent* event) override;
    void mousePressEvent(QGraphicsSceneMouseEvent* event) override ;
    void mouseMoveEvent(QGraphicsSceneMouseEvent* event) override;


};

#endif // BIRD_H
