#ifndef LEVEL3_H
#define LEVEL3_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level3:public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level3();
    void loadLevel3();
};

#endif // LEVEL3_H
