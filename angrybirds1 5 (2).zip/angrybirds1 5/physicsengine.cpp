#include <QGraphicsView>
#include <QGraphicsScene>
#include <QBrush>
#include <QPixmap>
#include <QGraphicsTextItem>
#include "bird.h"
#include "physicsengine.h"
#include "target.h"
#include "barrier.h"
#include "slingshot.h"
#include "box.h"
#include "level2.h"
#include "level3.h"
#include "level4.h"
#include "level5.h"
#include "level6.h"
#include "level7.h"
#include "level8.h"
#include "level9.h"
#include "level10.h"
#include "congratwindow.h"
#include <QApplication>
#include <QUrl>
#include <QPropertyAnimation>
int trialcount; //global variables
int level=1;
int targetCount=0;
class Slingshot;
PhysicsEngine::PhysicsEngine()
{

    trialcount =12; //the user has 12 trials to hit the target

    view = new QGraphicsView();
    scene = new QGraphicsScene();
    scene->setSceneRect(0, 0, 1200, 600); //creating a graphics view and a scene and setting its size
    // Set the scene to the view
    view->setScene(scene);
    // Set the fixed size of the view
    view->setFixedSize(1200, 600);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // Set the background image
    QPixmap backgroundImage(":/Images/background.jpg");
    view->setBackgroundBrush(QBrush(backgroundImage));

    //creating a slingshot object to display in all levels
    Slingshot slingshot;
    QPixmap image1=slingshot.getPixMap1(); //the slingshot image is split to three parts: left part, right part and string
    QGraphicsPixmapItem* pixmap1Item = new QGraphicsPixmapItem(image1);
    pixmap1Item->setPos(190, 400); //setting position of left part
    scene->addItem(pixmap1Item);

    QGraphicsPathItem* stringItem = slingshot.getString();
    scene->addItem(stringItem); //adding string

    gameOverText = new QGraphicsTextItem;
    gameOverText->setPlainText("Game Over!");
    gameOverText->setFont(QFont("times", 60));
    gameOverText->setDefaultTextColor(Qt::red);
    gameOverText->setPos(400, 250);
    gameOverText->setZValue(1);
    scene->addItem(gameOverText); //initializing the text that would display when the player is out of trials
    gameOverText->setVisible(false); //it is only visible when condition is true (when trialcount==0)


    newbird = new bird(this);
    spawn(); //call the function to generate a bird

    QPixmap image2=slingshot.getPixMap2();
    QGraphicsPixmapItem* pixmap2Item = new QGraphicsPixmapItem(image2);
    pixmap2Item->setPos(160,400); //setting position of left part of slingshot
    scene->addItem(pixmap2Item);

    scene->addItem(this->trials);//adding the count of the trials to the scene to display

    levelText->setPlainText("Level: " + QString::number(level));
    levelText->setFont(QFont("times", 15));
    levelText->setDefaultTextColor(QColor(75,0,130));
    levelText->setPos(1110, 0);//initializing the text that displays the level
    scene->addItem(levelText); //adding the text to the scene

    Gen_target(910,335); //calling the function to create the first target

    Gen_box(870, 490); //calling the function that adds the boxes that the target stands on
    Gen_box(870,390);

       view->show();
}

void PhysicsEngine::Gen_target(double X, double Y) //function to generate a target when needed as some levels need more than 1 target)
{

       Target* newtarget = new Target;
       scene->addItem(newtarget);
       newtarget->setPos(X , Y );
       newtarget->show();
       targetCount++;

}

void PhysicsEngine::Gen_box(double X, double Y)//function to generate a boxes when needed
{
       Box* newBox = new Box;
       scene->addItem(newBox);
       newBox->setPos(X , Y );
       newBox->show();
}


void PhysicsEngine::spawn(){ //function that regenerates a bird and returns it to its initial position and sets the trial count on screen
       scene->addItem(newbird);
       newbird->setPos(175, 410);
       newbird->show();

       trials->setPlainText("Trials: " + QString::number(trialcount));
       trials->setFont(QFont("times", 15));
       if(trialcount > 6)
           trials->setDefaultTextColor(QColor(4,175,112)); //if trialcount is less than 6, the color of the text turns red
       else
           trials->setDefaultTextColor(Qt::red);

       if (trialcount == 0 ){
           scene->removeItem(newbird);
           //delete newbird;
           this->gameOverText->setVisible(true); //if the player is out of trials, bird is removed and "game over" is displayed



}
}
void PhysicsEngine::Gen_barrier(double X, double Y)//function to generate a barrier when needed (obstacle)
{

   barrier* wall = new barrier;
   scene->addItem(wall);
   wall->setPos(X , Y);
   wall->show();


}

void PhysicsEngine::loadLevel(){//the function checks the level and istantiates the corresponding class to initialize the level features

           if(level==2){
               view->hide(); //the previous view is hidden first so that only one window is visible at a time
               Level2* level2Instance = new Level2;
               level2Instance->loadLevel2();
           }
           if(level==3){
               view->hide();
               Level3* level3Instance = new Level3;
               level3Instance->loadLevel3();
           }
           if(level==4){
               view->hide();
               Level4* level4Instance = new Level4;
               level4Instance->loadLevel4();
           }
           if(level==5){
               view->hide();
               Level5* level5Instance = new Level5;
               level5Instance->loadLevel5();
           }
           if(level==6){
               view->hide();
               Level6* level6Instance = new Level6;
               level6Instance->loadLevel6();
           }
           if(level==7){
               view->hide();
               Level7* level7Instance = new Level7;
               level7Instance->loadLevel7();
           }
           if(level==8){
               view->hide();
               Level8* level8Instance = new Level8;
               level8Instance->loadLevel8();
           }
           if(level==9){
               view->hide();
               Level9* level9Instance = new Level9;
               level9Instance->loadLevel9();
           }
           if(level==10){
               view->hide();
               Level10* level10Instance = new Level10;
               level10Instance->loadLevel10();
           }
           if (level == 11){ //if player has passed level 10, a congratulations window is shown
               view->hide();
               congratwindow* done = new congratwindow;
               done->show();


           }



}
PhysicsEngine::~PhysicsEngine() {
    // Ensure all targets are deleted when the PhysicsEngine instance is destroyed
    deleteAllTargets();
    //deleteAllBirds();
}

void PhysicsEngine::deleteAllTargets() {
    // Iterate through the scene and find all Target items
    QList<QGraphicsItem*> allItems = scene->items();
    for (QGraphicsItem* item : allItems) {
        Target* target = dynamic_cast<Target*>(item);
        if (target) {
            // Remove from scene and delete the target
            scene->removeItem(target);
            delete target;
        }
    }

    // Clear the targetCount
    targetCount = 0;
}

/*void PhysicsEngine::deleteAllBirds(){
    QList<QGraphicsItem*> allItems = scene->items();
    for (QGraphicsItem* item : allItems) {
        bird* birds = dynamic_cast<bird*>(item);
        if (birds) {
            // Remove from scene and delete the target
            scene->removeItem(birds);
            delete birds;
        }
    }
}*/
