#include "box.h"

Box::Box()
{
    QPixmap boxpixmap (":/Images/angrybirdsBox-removebg-preview.png");
    boxpixmap = boxpixmap.scaledToWidth(100);
    boxpixmap = boxpixmap.scaledToHeight(100);
    setPixmap(boxpixmap);
}
