#include "selectlevel.h"
#include "ui_selectlevel.h"
#include "physicsengine.h"
#include "bird.h"
#include "level2.h"
#include "level3.h"
#include "level4.h"
#include "level5.h"
#include "level6.h"
#include "level7.h"
#include "level8.h"
#include "level9.h"
#include "level10.h"
#include <QApplication>
#include <QUrl>

selectlevel::selectlevel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::selectlevel)
{
    ui->setupUi(this);
}

selectlevel::~selectlevel()
{
    delete ui;
}

void selectlevel::on_l2_pb_clicked()
{
    level=2;
    Level2* level2Instance = new Level2;
    level2Instance->loadLevel2();
 this->close();

}



void selectlevel::on_l1_pb_clicked()
{
    level=1;
    PhysicsEngine* level1 = new PhysicsEngine;
    this->close();

}


void selectlevel::on_l3_pb_clicked()
{
    level=3;
    Level3* level3Instance = new Level3;
    level3Instance->loadLevel3();
    this->close();

}




void selectlevel::on_l4_pb_clicked()
{
    level=4;
    Level4* level4Instance = new Level4;
    level4Instance->loadLevel4();
    this->close();
}


void selectlevel::on_l5_pb_clicked()
{
    level=5;
    Level5* level5Instance = new Level5;
    level5Instance->loadLevel5();
    this->close();
}



void selectlevel::on_l6_pb_clicked()
{
    level=6;
    Level6* level6Instance = new Level6;
    level6Instance->loadLevel6();
    this->close();
}



void selectlevel::on_l7_pb_clicked()
{
    level=7;
    Level7* level7Instance = new Level7;
    level7Instance->loadLevel7();
    this->close();
}



void selectlevel::on_l8_pb_clicked()
{
    level=8;
    Level8* level8Instance = new Level8;
    level8Instance->loadLevel8();
    this->close();
}


void selectlevel::on_l9_pb_clicked()
{
    level=9;
    Level9* level9Instance = new Level9;
    level9Instance->loadLevel9();
    this->close();
}




void selectlevel::on_l10_pb_clicked()
{
    level=10;
    Level10* level10Instance = new Level10;
    level10Instance->loadLevel10();
    this->close();
}

