#ifndef CONGRATWINDOW_H
#define CONGRATWINDOW_H

#include <QDialog>

namespace Ui {
class congratwindow;
}

class congratwindow : public QDialog
{
    Q_OBJECT

public:
    explicit congratwindow(QWidget *parent = nullptr);
    ~congratwindow();

private slots:
    void on_Exit_clicked();

private:
    Ui::congratwindow *ui;
};

#endif // CONGRATWINDOW_H
