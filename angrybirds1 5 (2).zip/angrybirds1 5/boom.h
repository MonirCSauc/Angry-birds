#ifndef BOOM_H
#define BOOM_H
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>

class boom: public QGraphicsPixmapItem, public QObject
{
public:
    boom();
};

#endif // BOOM_H
