#ifndef LEVEL9_H
#define LEVEL9_H
#include "physicsengine.h"
#include "barrier.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level9: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level9();
    void loadLevel9();
    void Gen_barrier( double X , double Y);
};

#endif // LEVEL9_H
