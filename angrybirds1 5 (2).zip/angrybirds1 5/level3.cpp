#include "level3.h"

Level3::Level3()
{
    QGraphicsTextItem* newLevel= new QGraphicsTextItem("Level 3");
    newLevel->setFont(QFont("times", 40));
    newLevel->setDefaultTextColor(Qt::green);
    newLevel->setPos(300, 250);
    QTimer::singleShot(1000, [=](){
        PhysicsEngine::scene->addItem(newLevel);
    });
    QTimer::singleShot(7000, [=](){PhysicsEngine::scene->removeItem(newLevel);});
}

void Level3::loadLevel3(){

    Gen_barrier(550, 500);
    Gen_barrier(550, 400);
    Gen_barrier(550, 300);

    PhysicsEngine::scene->update();
}
