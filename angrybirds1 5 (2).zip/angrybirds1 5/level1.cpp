#include "level1.h"

Level1::Level1()
{


}

Level1::loadLevel1()
{
    Gen_target(890, 325);
}
