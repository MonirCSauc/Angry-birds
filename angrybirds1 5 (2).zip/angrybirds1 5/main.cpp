#include "ww.h"
#include<ctime>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ww w;
    srand(0);
    w.show();

    return a.exec();
}
