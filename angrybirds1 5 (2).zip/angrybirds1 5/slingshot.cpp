#include "slingshot.h"

Slingshot::Slingshot()
{
    sling1 = QPixmap(":/Images/sling.png");
    sling2 = QPixmap(":/Images/sling2.png");
    string = new QGraphicsPathItem();
    string->setZValue(-1); //so that the string is behind the bird
    timer2 = new QTimer(this);
    connect(timer2, &QTimer::timeout, this, &Slingshot::updateMovedString); //timer that continuously calls the updateMovedString function
    //to continuously update the slingshot string with the bird's current position according to how the player is moving it

}

QPixmap Slingshot::getPixMap1() const{
    return sling1;
}

QPixmap Slingshot::getPixMap2() const{
    return sling2;
}

QGraphicsPathItem* Slingshot::getString() const{
    return string;
}

void Slingshot::recoil(QPointF birdPosition) { //function that is called in bird.cpp and continuously takes the bird's current position
    birdPos=birdPosition;
    timer2->start(10);  // once that function is called, it means that the bird started moving. So, the timer starts.
    //the updateMovedString function is called every 10 milliseconds according to the timer
}


void Slingshot::updateMovedString(){
    // Define the starting, ending, and initial positions of the string
    QPointF startPoint(170, 430);
    QPointF endPoint(220, 430);
    QPointF initialPos(170, 415);
    // Clear the existing path of the string
    path.clear();
    string->setPath(path);
    // Set the width of the string using a pen
    QPen stringPen=string->pen();
    stringPen.setWidth(15);
    string->setPen(stringPen);

    // Calculate the stretch vector(represents the direction and magnitude of string  being stretched as a result of the bird's movement)
    QPointF stretchVector = birdPos - initialPos;

    // Calculate the control point for the cubic Bezier curve
    QPointF controlPoint = birdPos + stretchVector / 3;

    // Create the curved path

    path.moveTo(startPoint);

    path.cubicTo(birdPos +stretchVector, controlPoint, endPoint);

    string->setPath(path);

    string->update();

    scene()->addItem(string);

}

void Slingshot:: reverse(){ //function that is called when the bird is released to return string to initial position
    timer2->stop(); //stops the timer so the updateMovedString function stops executing
    QPointF startPoint(170, 430);
    QPointF endPoint(210, 430);
    path.clear(); //clears stretched string
    path.moveTo(startPoint);
    path.quadTo(startPoint, endPoint);
    string->setPath(path);
    string->update();


}
void Slingshot::endRecoil(){//function that disconnects the timer
    disconnect(timer2, &QTimer::timeout, this, &Slingshot::updateMovedString);
    timer2->stop();

    }
Slingshot::~Slingshot() {
        // Clean up the string object in the destructor
        delete string;
    }


