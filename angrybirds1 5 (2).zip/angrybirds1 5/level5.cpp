#include "level5.h"

Level5::Level5()
{
    QGraphicsTextItem* newLevel= new QGraphicsTextItem("Level 5");
    newLevel->setFont(QFont("times", 40));
    newLevel->setDefaultTextColor(Qt::green);
    newLevel->setPos(300, 250);
    QTimer::singleShot(1000, [=](){
        PhysicsEngine::scene->addItem(newLevel);
    });
    QTimer::singleShot(7000, [=](){PhysicsEngine::scene->removeItem(newLevel);});
}

void Level5::loadLevel5()
{
    Gen_barrier(550, 500);
    Gen_barrier(550, 370);
    Gen_target(990, 235);
    Gen_box(970, 490);
    Gen_box(970, 390);
    Gen_box(970, 290);

    PhysicsEngine::scene->update();
}
