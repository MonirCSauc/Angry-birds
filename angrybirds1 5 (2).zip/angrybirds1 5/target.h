#ifndef TARGET_H
#define TARGET_H
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>


class Target:public QGraphicsPixmapItem, public QObject
{
public:

    Target();
    QPointF getPos();
    QRectF boundingRect();
    enum { Type = UserType + 1 };
    int type() const override { return Type; }
private:
    QPointF position;
};

#endif // TARGET_H
