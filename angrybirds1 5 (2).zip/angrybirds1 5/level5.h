#ifndef LEVEL5_H
#define LEVEL5_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level5: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level5();
    void loadLevel5();
};

#endif // LEVEL5_H
