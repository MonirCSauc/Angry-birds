#include "congratwindow.h"
#include "ui_congratwindow.h"

congratwindow::congratwindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::congratwindow)
{
    ui->setupUi(this);
}

congratwindow::~congratwindow()
{
    delete ui;
}

void congratwindow::on_Exit_clicked()
{
    exit(1);
}

