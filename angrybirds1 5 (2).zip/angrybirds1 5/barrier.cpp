#include "barrier.h"

barrier::barrier()
{
    QPixmap barrierpixmap (":/Images/barrier.png");
    barrierpixmap = barrierpixmap.scaledToWidth(100);
    barrierpixmap = barrierpixmap.scaledToHeight(100);
    setPixmap(barrierpixmap);

}

QPointF barrier::getPos()
{
    return position;
}
