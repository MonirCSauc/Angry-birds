#include "level6.h"
#include "barrier.h"

Level6::Level6()
{

    QGraphicsTextItem* newLevel= new QGraphicsTextItem("Level 6");
    newLevel->setFont(QFont("times", 40));
    newLevel->setDefaultTextColor(Qt::green);
    newLevel->setPos(300, 250);
    QTimer::singleShot(1000, [=](){
        PhysicsEngine::scene->addItem(newLevel);
    });
    QTimer::singleShot(7000, [=](){PhysicsEngine::scene->removeItem(newLevel);});
}

void Level6::Gen_barrier(double X , double Y){


    barrier* wall = new barrier;
    PhysicsEngine::scene->addItem(wall);
    wall->setPos(X , Y);
    wall->show();

    // Create a QTimer to move the barrier. To make the obstacles harder, we created a line with moving barriers.
    //each new level afterwards will make the barriers move at a greater speed
    QTimer* timer = new QTimer();
    QObject::connect(timer, &QTimer::timeout, [=]() {
        wall->setPos(wall->x(), wall->y() + 1);

        if (wall->y() > PhysicsEngine::scene->height()) {
            wall->setPos(wall->x(), 0);
        }
    });

    // Start the timer with a timeout interval of 16ms (for ~60fps)
    timer->start(20);




}



void Level6::loadLevel6(){

    Gen_barrier(550, 500);
    Gen_barrier(550, 200);
    Gen_target(990, 235);
    Gen_box(970,490);
    Gen_box(970,390);
    Gen_box(970, 290);

    PhysicsEngine::scene->update();
}
