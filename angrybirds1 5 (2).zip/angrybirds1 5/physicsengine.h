#ifndef PHYSICSENGINE_H
#define PHYSICSENGINE_H
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

extern int level;
extern int targetCount;
extern int trialcount;
class bird;

class PhysicsEngine: public QObject
{


    Q_OBJECT;


protected:
    QTimer* timer;
    bird* newbird;


public:
    QGraphicsScene* scene;
    QGraphicsView* view;
    QGraphicsTextItem* trials = new QGraphicsTextItem("Trials: " + QString::number(trialcount));
    QGraphicsTextItem* levelText= new QGraphicsTextItem("Level: " + QString::number(level));


    PhysicsEngine();
    PhysicsEngine(int x);
    void Gen_target(double X , double Y);
    virtual void Gen_barrier(double X, double Y);
    void Gen_box(double X, double Y);

    QGraphicsTextItem* gameOverText;
    void spawn();
    void loadLevel();
    void deleteAllTargets();
    void deleteAllBirds();

        // Destructor to clean up memory
        ~PhysicsEngine();

};

#endif // PHYSICSENGINE_H
