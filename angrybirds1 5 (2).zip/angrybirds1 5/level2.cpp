#include "level2.h"

Level2::Level2()
{
    QGraphicsTextItem* newLevel= new QGraphicsTextItem("Level 2"); //when the user enters a new level, a message is displayed to indicate that they reached a new level
    newLevel->setFont(QFont("times", 40));
    newLevel->setDefaultTextColor(Qt::green);
    newLevel->setPos(300, 250);
    QTimer::singleShot(1000, [=](){
    PhysicsEngine::scene->addItem(newLevel);
    }); //we add the message to the scene after 1 second
    QTimer::singleShot(3000, [=](){PhysicsEngine::scene->removeItem(newLevel);}); //so that the user has time to read the message, we remove it after 3 seconds
}

void Level2::loadLevel2(){
//each loadLevel function for every level class calls the necessary function in the physics engine that display the level features
    Gen_barrier(550, 500);
    Gen_barrier(550, 400);
    PhysicsEngine::scene->update();
}
