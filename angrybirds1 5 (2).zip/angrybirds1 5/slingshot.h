#ifndef SLINGSHOT_H
#define SLINGSHOT_H
#include <QPixmap>
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include <QDebug>
#include <QTimer>
#include <QTimerEvent>




class Slingshot: public QObject, public QGraphicsPixmapItem
{
private:
    QPixmap sling1;
    QPixmap sling2;
    QGraphicsPathItem* string;
    QPainterPath path;
    QTimer* timer2;
    QPointF birdPos;

public:
    Slingshot();
    QPixmap getPixMap1() const;
    QPixmap getPixMap2() const;
    QGraphicsPathItem* getString() const;
    void recoil(QPointF birdPosition);
    void updateStringPosition();
    void updateMovedString ();
    void endRecoil();
    void reverse();
    ~Slingshot();
};

#endif // SLINGSHOT_H



