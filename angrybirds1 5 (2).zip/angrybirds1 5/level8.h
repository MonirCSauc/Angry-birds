#ifndef LEVEL8_H
#define LEVEL8_H
#include "physicsengine.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <cstdlib>
#include <ctime>

class Level8: public QGraphicsPixmapItem, public PhysicsEngine
{
public:
    Level8();
    void loadLevel8();
};

#endif // LEVEL8_H
