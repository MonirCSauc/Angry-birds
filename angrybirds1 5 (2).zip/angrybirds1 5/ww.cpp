#include "ww.h"
#include "ui_ww.h"
#include "selectlevel.h"
#include <QUrl>
#include <QApplication>


ww::ww(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ww),
    player(new QMediaPlayer(this))
{
    ui->setupUi(this); //Opens the main window which prompts the user to play
    player->setMedia(QUrl("qrc:/Sounds/30_Second__Angry_Bird_Theme.mp3")); //adding background music to the game
    QMediaPlaylist *playlist = new QMediaPlaylist();
    playlist->addMedia(QUrl("qrc:/Sounds/30_Second__Angry_Bird_Theme.mp3"));
    //Creating a playlist makes the music loop throughout the game
    playlist->setPlaybackMode(QMediaPlaylist::Loop);
    // Set the playlist to the media player
    player->setPlaylist(playlist);
    player->setVolume(50);
    player->play();
}

ww::~ww()
{
    delete ui;
    delete player;
}

void ww::on_Play_button_clicked()
{
    selectlevel* select= new selectlevel(); //once the play button is clicked, a window appears which makes the user choose the level
    select->show();
    this->close();
}
