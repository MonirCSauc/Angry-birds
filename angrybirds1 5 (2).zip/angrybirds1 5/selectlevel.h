#ifndef SELECTLEVEL_H
#define SELECTLEVEL_H

#include <QDialog>

namespace Ui {
class selectlevel;
}

class selectlevel : public QDialog
{
    Q_OBJECT

public:
    explicit selectlevel(QWidget *parent = nullptr);
    ~selectlevel();

private slots:
    void on_l2_pb_clicked();

    void on_l1_pb_clicked();

    void on_l3_pb_clicked();

    void on_l4_pb_clicked();

    void on_l5_pb_clicked();

    void on_l6_pb_clicked();

    void on_l7_pb_clicked();

    void on_l8_pb_clicked();

    void on_l9_pb_clicked();

    void on_l10_pb_clicked();

private:
    Ui::selectlevel *ui;
};

#endif // SELECTLEVEL_H
